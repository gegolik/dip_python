"""Cree una función lamba que compruebe si un número es par o impar."""

paridad = lambda nro: (nro % 2) == 0


print(paridad(168))
print(paridad(7)) 