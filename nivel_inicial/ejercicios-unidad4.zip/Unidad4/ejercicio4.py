""" Crear una función lambda que tome como parámetro una frase y la escriba al revés."""


invertir = lambda frase: frase[::-1]


f = "hola juan carlos"

print(f)
print(invertir(f))

"""Como funcionan los indices dentro de las listas ejemplo lista[1:], lista[::-1]...."""